from datetime import datetime
from socket import *
import traceback  #for debugging
import re #regualr expresion to get


class Cache:
    def __init__(self, url, payload):
        self.url = url #[host,request line]
        self.payload = payload
        self.time_recv = datetime.now()
        self.num_of_requests = 1
        self.cache_limit = 100 #assume we have based the limit of the cache not on size of the object 
                              #but on the number of objects in the cache
        self.cache_timeout = 86400 #entry can only exist for 24 hours
        self.last_modfied_since = self.get_last_modified(self.payload)

    def time(self): #returns time interval, which is how long ago this cache item was last accessed
        current_time = datetime.now() 
        time_since_last_call_self = current_time - self.time_recv
        return time_since_last_call_self;        
    def __lt__(self, other):
        current_time = datetime.now() 
        time_since_last_call_self = current_time - self.time_recv
        time_since_last_call_other = current_time - other.time_recv
        priority_self = (time_since_last_call_self.total_seconds() + 1) #/ self.requests
        priority_other = (time_since_last_call_other.total_seconds() + 1)# / other.requests
        return priority_self > priority_other
        
    def is_valid(self, cache_timeout): #checks if the cache entry has not expired
        return (datetime.now() - self.time_recv).seconds < cache_timeout

    def update_cache(self): #updates last access time
        self.time_recv = datetime.now()
        self.num_of_requests += 1

    def get_payload(self):
        return self.payload

    def check_modified_since(self):
        try:
            clientSocket = socket(AF_INET, SOCK_STREAM)
            clientSocket.settimeout(5)
            clientSocket.connect((self.url[0][1:], 80))

            conditional_get_request = f"GET {self.url[1]} HTTP/1.1\r\nHost: {self.url[0][1:]}\r\nIf-Modified-Since: {self.time_recv.strftime('%a, %d %b %Y %H:%M:%S')}\r\n\r\n"
            clientSocket.send((conditional_get_request).encode())
            
            response_from_server = clientSocket.recv(4096).decode()
            print(response_from_server)
            clientSocket.close()

            # Check if the server responded with a 304 status code (Not Modified)
            if self.get_last_modified(response_from_server) == self.last_modfied_since:
                return False
            else:
                # Content has been modified
                return True

        except Exception as e:
            # If there's an error in the conditional GET request, treat it as if the content is modified
            traceback.print_exc()
            return True
        
    def get_last_modified(self,response):
        last_modified_match = re.search(r'Last-Modified: (.+)', response)
        return str(last_modified_match)[57:-7]
    

    cache = {}


    