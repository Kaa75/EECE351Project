from socket import *
from datetime import datetime 
import threading
import time
import pandas as pd
import hashlib
import os
import uuid
from Cache import *


requests_per_second ={} #dictionary of IP addresses and number of requests per second for each IP address (to monitor hosts' traffic)
bots = set()
lock = threading.Lock()
banned_URLs = {"www.bannedexample.com"}
banned_server_IPs = set()
banned_client_IPs = set() # set as {"127.0.0.1"} for testing

cache = {}
cache_timeout = 86400 #in seconds, 24 hours

def deleteOldestCache(): #deleted least recently used object
    if not cache:
     return None  
    max_url = None
    max_time_value = None
    for url, cache_instance in cache.items():
     current_time_value = cache_instance.time()
     if max_time_value == None or (current_time_value > max_time_value):
            max_url = url
            max_time_value = current_time_value
    del cache[max_url]


def add_cache(caches): 
    if len(cache) >= 100:
      deleteOldestCache() # If the size exceeds 100, remove the cache which is least recently used
    cache[caches.url[0]+ caches.url[1]] = caches


#this resets the request_count every second
def reset_request_count():
    while (True):
        time.sleep(1) #set as 20 for testing
        with lock: #ensuring thread safety
            requests_per_second.clear()
    		
reset_thread = threading.Thread(target = reset_request_count) #start the thread for clearing requests_per_second every second
reset_thread.start()	

#Ecrypting password using SHA-256 Algorithm
def hashPassword(password): #source: https://www.tutorialspoint.com/how-to-hash-passwords-in-python
	return (hashlib.sha256(password.encode('utf-8'))).hexdigest()
	

def authenticateUser(connectionSocket, clientIP):
    hosts = pd.read_excel('host_credentials.xlsx') #stores the hosts' IP addresses and passwords. Used as "database"
    print("client IP: ",clientIP)
    if hosts[hosts['IP']==clientIP].shape[0]>0: #host is registered -> Request login info
        username = ""
        password = ""
        try: 
            #Receive the username
            username = connectionSocket.recv(1024).decode()
    	
            #Receive the password
            password = connectionSocket.recv(1024).decode()
    		
        except Exception as e:
            
            print(e)
            return False	
        
        if ((username == hosts.loc[hosts['IP'] == clientIP, 'Username'].values[0]) & (hashPassword(password) == hosts.loc[hosts['IP'] == clientIP, 'HashedPassword'].values[0])):
            return True
        else:
           
            return False
        
    else:#host is not registered -> Request registration info
        username = ""
        password = ""
        try: 
            #Receive the username
            username = connectionSocket.recv(1024).decode()
            #Receive the password
            
            password = connectionSocket.recv(1024).decode() 
    		
        except Exception as e:
            
            print(e)
            return False	
          
        newHostInfo = {
            'IP': clientIP,
            'Username': username,
            'HashedPassword' : hashPassword(password)      	
        }
   	
        hosts = pd.concat([hosts, pd.DataFrame([newHostInfo])], ignore_index=True)
        hosts.to_excel(os.path.join(os.getcwd(), 'host_credentials.xlsx'), index = False) #Update excel sheet that we put in the same directory as the server file


        return True
        
	  
def handleClient(T):
    connectionSocket=T[0]
    addr=T[1]
    connectionSocket.settimeout(10) #setting timeout value on all socket operations. source: https://stackoverflow.com/questions/38544493/python-socket-programming-exception-handling 

    ####Apply Filtering on Some Clients  	
    clientIP =  addr[0]
    if (clientIP in bots):
        connectionSocket.send("You have been flagged as a bot! Access Denied!".encode())
        connectionSocket.close()
        return
    	
    if (clientIP in banned_client_IPs):
        connectionSocket.send("Your IP Address has been banned!".encode())
        connectionSocket.close()
        return        

    ##Receive request from client
    try:
        request=connectionSocket.recv(4096).decode()
        requestTime=datetime.now()
    except Exception as e:
        connectionSocket.close()
        return       
    try:
        request_header_and_payload=request.split('\r\n\r\n') #splitting the header from the payload, results in the list request_header_and_payload=[header,payload]
        requestHeader=request_header_and_payload[0] 
        requestPayload=request_header_and_payload[1] 
        requestLines=requestHeader.split('\r\n') #each element of this list is a line from the header. requestLines[0] is the request line, requestLines[1] contains the "Host" header..
        
        parsedRequest={} #maps header field name to value
    
        
        for i in range(1,len(requestLines)-2): #looping over all the lines except the request line. The last two elements are left out because they are empty strings (due to \r\n\r\n)
            temp=requestLines[i].split(':')     
            parsedRequest[temp[0]]=temp[1]
    except:
        connectionSocket.send("Bad request format".encode())
        connectionSocket.close()
        return
    parsedRequest["request line"]=requestLines[0].split()
    print("This machine's current IP address: ", gethostbyname(gethostname()))
    print("This machine's MAC address: ",':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff) for elements in range(5, -1, -1)]))
    print()
    print("\nRequest Type: ",parsedRequest['request line'][0])
    print("Requested URL: "+parsedRequest['Host']+parsedRequest['request line'][1])  
    print("Requested by host with IP address ",addr[0])
    print("Time of request: ",requestTime)
    
    ####Updating request count for client
    
    with lock:
        if clientIP in requests_per_second:
            requests_per_second[clientIP] +=1 #client has made a new request this second
        else:
            requests_per_second[clientIP] =1 #client's first request this second

    if (requests_per_second[clientIP] >=50): #if the client has made over 50rps, then it's probably a bot  #set as 2 for testing
        bots.add(clientIP)
        connectionSocket.send("You have been flagged as a bot! Access Denied!".encode())
        connectionSocket.close()
        return
        
    
    #Checking if client is trying to access a banned URL 
    if parsedRequest['Host'][1:] in banned_URLs:
        print("Banned Successfully")
        connectionSocket.send("Website Requested is Banned!".encode())
        connectionSocket.close()
        return	
    

    #Checking if client is trying to access a banned server by IP
    serverIP = gethostbyname(parsedRequest['Host'][1:])
    if serverIP in banned_server_IPs:
        connectionSocket.send("Website Requested is Banned!".encode())
        connectionSocket.close()
        return	
    

    
    #Apply User Authentication
    if (authenticateUser(connectionSocket, clientIP) == False):
        connectionSocket.send("User Authentication Failed!".encode())
        connectionSocket.close()
        return
    else:
        print()
        connectionSocket.send("User Authentication Successful!".encode())
       
    try:
        url=[parsedRequest['Host'], parsedRequest['request line'][1]]
        #check if requested object is in cache and is up to date and not modified
        if (url[0]+url[1] in cache) and cache[url[0]+url[1]].is_valid(cache_timeout) and not cache[url[0]+url[1]].check_modified_since():
            # add is modified since
            print("Cache hit")
            print("Response sent to the client at time: ",datetime.now())
            connectionSocket.send(cache[url[0]+url[1]].get_payload().encode())
            connectionSocket.close()
            cache[url[0]+url[1]].update_cache()
        else: #object not in cache
            #The proxy server now acts as a client to contact original server:
            clientSocket = socket(AF_INET, SOCK_STREAM) #to communicate with original server
            clientSocket.settimeout(10)
            clientSocket.connect((parsedRequest['Host'][1:],80))
            clientSocket.send(request.encode())
            actualRequestTime=datetime.now()

            print("Actual request sent at: ",actualRequestTime)
            responseFromServer=(clientSocket.recv(4096)).decode() #receive from original server
            print("Response received from original server at time: ",datetime.now())
            connectionSocket.send(responseFromServer.encode()) #relay to the client
            print("Response sent to the client at time: ",datetime.now())
            cached_item = Cache(url, responseFromServer)
            add_cache(cached_item)
            clientSocket.close()
            connectionSocket.close()

    except Exception as e:
        connectionSocket.send(str(e).encode())
        connectionSocket.close()
        return
serverPort=12000
serverSocket=socket(AF_INET,SOCK_STREAM)
serverSocket.bind(('127.0.0.1',serverPort))
serverSocket.listen(100)

while True:
    connectionSocket, addr = serverSocket.accept()
    t1=threading.Thread(target=handleClient,args=((connectionSocket,addr,),)) #create a thread for each client
    t1.start()
