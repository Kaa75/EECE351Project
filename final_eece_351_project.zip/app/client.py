from flask import Flask,request, render_template, redirect, url_for
from socket import *
import time
app = Flask(__name__) #create instance of flask
response=''

@app.route("/actual_page", methods=['POST','GET']) 
def show_page():
	global response
	responseSplit=response.split('\r\n\r\n')
	payload=''
	error_msg=''
	if len(responseSplit)>1: #a proper response is returned
		payload=responseSplit[1]
	else:
		error_msg=response
	return render_template("actual_page.html",response=payload,error_msg=error_msg)

@app.route("/", methods=['POST','GET']) 
def main():
	global response
	username=request.form.get('username')
	password=request.form.get('password')
	sentence = request.form.get('req')#"""GET /wireshark-labs/HTTP-wireshark-file1.html HTTP/1.1\r\nHost: gaia.cs.umass.edu\r\nConnection: keep-alive\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-GB,en;q=0.9,ar-LB;q=0.8,ar;q=0.7,en-US;q=0.6 \r\n\r\n<!doctype

	if username!='' and password!='' and username is not None and password is not None and sentence!='' and sentence is not None:
		serverName = 'localhost'
		serverPort = 12000
		clientSocket = socket(AF_INET, SOCK_STREAM)
		clientSocket.connect((serverName,serverPort))
		sentence= sentence.replace("\\r\\n", '\r\n')
		try:
			clientSocket.send(sentence.encode())
			time.sleep(1)
			clientSocket.send(username.encode())
			print("sent ", username,password)
			time.sleep(1)
			clientSocket.send(password.encode())


			authenticationResult = clientSocket.recv(1024).decode()
			print(authenticationResult)
			if (authenticationResult != "User Authentication Failed!"):
				response = clientSocket.recv(1024).decode()
				print ('From Server:', response)
				clientSocket.close()
			else:
				response='Authentication failed'
			return redirect(url_for('show_page'))
		except Exception as e:
			response='You are banned, or the requested website is banned, or the request is in bad format'
			return redirect(url_for('show_page'))
			
		
	return render_template("client_login.html")


if __name__ == "__main__":
    app.run()