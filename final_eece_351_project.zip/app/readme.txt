Note that the following libraries must be installed: socket, datetime, threading, time, pandas, hashlib, os, re, flask.
run the server first on one terminal, then the client on another terminal.

The server runs on 'localhost', port=12000
1-run the server on one terminal, and the client on another terminal. In the client's terminal, a message like this will appear:  * Running on http://127.0.0.1:5000 . Paste this link in your browser.

2- Make sure the excel file has read/write permissions, and editing is enabled. Close the excel file before running the code. The first time you enter a username/password, you would be registering. To run the code again later, enter the same username and password you entered first. or delete the entries in the excel file to register again.

3-enter the HTTP request in the correct format. Example:
GET /wireshark-labs/HTTP-wireshark-file1.html HTTP/1.1\r\nHost: gaia.cs.umass.edu\r\nConnection: keep-alive\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-GB,en;q=0.9,ar-LB;q=0.8,ar;q=0.7,en-US;q=0.6 \r\n\r\n<!doctype

another example:

GET /wireshark-labs/HTTP-wireshark-file2.html HTTP/1.1\r\nHost: gaia.cs.umass.edu\r\nConnection: keep-alive\r\nUpgrade-Insecure-Requests: 1\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\n\r\n


Note that websites that encode responses in other than ascii/utf-8 might not work.

4- the page should now be displayed in the browser. The HTTP response is printed in the client's terminal, and the request's details are printed in the server's terminal. Any errors are printed in the client/server terminal and displayed in the browser
